// src/__tests__/app.test.ts
import request from 'supertest';
import app from '../app'; // Your Express app

describe('Backend Routes', () => {
  it('should return 200 on GET /api/products', async () => {
    const response = await request(app).get('/api/products');
    expect(response.statusCode).toBe(401);
  });

  it('should return 404 for unknown route', async () => {
    const response = await request(app).get('/unknown-route');
    expect(response.statusCode).toBe(404);
  });
});
