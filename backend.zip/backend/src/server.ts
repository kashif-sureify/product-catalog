import app from "./app";
import { productDB } from "./config/productDB";
import { userDB } from "./config/userDB";

const PORT = process.env.PORT || 3000;

productDB()
  .then(() => {
    userDB();
  })
  .then(() => {
    app.listen(PORT);
  });
